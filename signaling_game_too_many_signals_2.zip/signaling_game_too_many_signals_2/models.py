from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)

import random


doc = """
A demo of how rounds work in oTree, in the context of 'matching pennies'
"""


class Constants(BaseConstants):
    name_in_url = 'experiment'
    players_per_group = 2

    #New stuff
    num_rounds = 60

    stakes = c(100)
    multiplier =4
    stakes_big=stakes*multiplier

    #New stuff end


class Subsession(BaseSubsession):



    def creating_session(self):
        self.group_randomly(fixed_id_in_group=True)


        self.session.vars['random_max_rounds']=5


        paying_round1=random.randint(1,self.session.vars['random_max_rounds'])
        paying_round2 = random.randint(1, self.session.vars['random_max_rounds'])
        while paying_round1 == paying_round2:
            paying_round2 = random.randint(1, self.session.vars['random_max_rounds'])

        self.session.vars['paying_round1']=paying_round1
        self.session.vars['paying_round2'] = paying_round2
        coin = random.randint(1, 2)
        self.session.vars['coin'] = coin

        randomizer = random.randint(1, 6)
        self.session.vars['randomizer'] = randomizer

        nature = random.randint(1, 2)
        self.session.vars['nature'] = nature



            # reverse the roles
           # matrix = self.get_group_matrix()
          #  for row in matrix:
           #     row.reverse()
           # self.set_group_matrix(matrix)
        #if self.round_number > 3:
           # self.group_like_round(3)


class Group(BaseGroup):
    state_Of_Nature = models.StringField(
        choices=['blue', 'green'],
        widget=widgets.RadioSelect
    )

    signal_Sent = models.StringField(
        choices=['Kortar', 'Majram', 'Tohzah'],
        widget=widgets.RadioSelect
    )

    act_Chosen = models.StringField(
        choices=['blue', 'green'],
        widget=widgets.RadioSelect
    )


    def set_payoffs(self):
        player_1 = self.get_player_by_role('Group A')
        player_2 = self.get_player_by_role('Group B')

        player_1.roundPayoff = 4
        player_2.roundPayoff = random.randint(1, 2)




        for player in [player_1, player_2]:

            player.payoff = player.roundPayoff
            if self.subsession.round_number == self.session.vars['paying_round1']:

               player.realizedPayoff = player.roundPayoff




class Player(BasePlayer):



    def other_player(self):
        return self.get_others_in_group()[0]

    coin = models.IntegerField(

    )

    roundPayoff = models.IntegerField()
    realizedPayoff = models.IntegerField()

    major = models.StringField()
    ethnicity = models.StringField()
    gender = models.StringField()

    def role(self):
        if self.id_in_group == 1:
            return 'Group A'
        if self.id_in_group == 2:
            return 'Group B'



