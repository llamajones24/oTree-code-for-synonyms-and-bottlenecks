from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
import random

class Instructions(Page):
    def is_displayed(self):
        return self.subsession.round_number ==1

class Instructions2(Page):
    def is_displayed(self):
        return self.subsession.round_number ==1

class Instructions3(Page):
    def is_displayed(self):
        return self.subsession.round_number ==1

class Diagram(Page):
    def is_displayed(self):
        return self.subsession.round_number ==1

class Instructions4(Page):
    def is_displayed(self):
        return self.subsession.round_number ==1

class RoleAssignment(Page):
    form_model = 'player'

    def is_displayed(self):
        return self.subsession.round_number ==1

class NewPartner(Page):
    timeout_seconds = 14
    form_model = 'player'
    form_model = 'group'
    form_fields = ['state_Of_Nature']

    def is_displayed(self):
        return self.player.id_in_group == 1

    def vars_for_template(self):
        nature = random.randint(1, 2)
        self.session.vars['nature'] = nature

        return{
    'nature': self.session.vars['nature'],
            }
    #def before_next_page(self):
            #self.group.state_Of_Nature = random.choice(['blue', 'green'])

class NewPartnerReceiver(Page):
    timeout_seconds = 14
    form_model = 'player'
    form_model = 'group'

    def is_displayed(self):
        return self.player.id_in_group == 2

        return{
    'nature': self.session.vars['nature'],
            }
    #def before_next_page(self):
            #self.group.state_Of_Nature = random.choice(['blue', 'green'])

class Send(Page):
    """This page is only for P1
    P1 sends amount (all, some, or none) to P2
    This amount is tripled by experimenter,
    i.e if sent amount by P1 is 5, amount received by P2 is 15"""



    form_model = 'player'
    form_model = 'group'
    form_fields = ['signal_Sent']





    def is_displayed(self):
        return self.player.id_in_group == 1

    def signal_Sent_choices(self):
        choices = ['Kortar', 'Majram', 'Tohzah']
        random.shuffle(choices)
        return choices



    def vars_for_template(self):
        opponent = self.player.other_player()

        randomizer = random.randint(1, 6)
        self.session.vars['randomizer'] = randomizer


        return {
            'reverse_player_in_previous_rounds': list(reversed(self.player.in_previous_rounds())),
            'player_in_previous_rounds': self.player.in_previous_rounds(),
        # (above) Gives them a list of things they did in the past. How we construct a history table
            'opponent_in_previous_rounds': opponent.in_previous_rounds(),

            'randomizer': self.session.vars['randomizer'],


            'state_Of_Nature': self.group.state_Of_Nature


            }

class ReceiverWaitPage(WaitPage):
        pass


class Receiver(Page):
    def is_displayed(self):
        return self.player.id_in_group == 2

    form_model = 'player'
    form_model = 'group'
    form_fields = ['act_Chosen']

    def act_Chosen_choices(self):
        choices = ['blue', 'green']
        random.shuffle(choices)
        return choices

    def vars_for_template(self):
        opponent = self.player.other_player()
        coin = random.randint(1, 2)
        self.session.vars['coin'] = coin
        list1 = list(range(1, 60))




        return {

            'player_in_previous_rounds': self.player.in_previous_rounds(),
            'reverse_player_in_previous_rounds': list(reversed(self.player.in_previous_rounds())),
        # (above) Gives them a list of things they did in the past. How we construct a history table
            'opponent_in_previous_rounds': opponent.in_previous_rounds(),

           # 'selected_payoff': player_in_all_rounds()[self.session.vars['paying_round']].payoff,
          'coin': self.session.vars['coin'],

            'state_Of_Nature': self.group.state_Of_Nature,
            'list1': list1

        }

class SenderWaitPage(WaitPage):
    pass








class ResultsWaitPage(WaitPage):



    wait_for_all_groups = True







class RoundResults(Page):
    timeout_seconds = 12
    form_model = 'group'
    form_model = 'player'

    def vars_for_template(self):

        return {

            'state_Of_Nature':self.group.state_Of_Nature

        }

class Survey(Page):
    form_model = 'player'
    form_fields = ['major', 'ethnicity', 'gender']

    def is_displayed(self):
        return self.subsession.round_number == self.session.vars['random_max_rounds']


class Results(Page):
    """This page displays the earnings of each player"""

    def is_displayed(self):
        return self.subsession.round_number == self.session.vars['random_max_rounds']+1


    def vars_for_template(self):
        opponent = self.player.other_player()

        return {
            'reverse_player_in_previous_rounds': list(reversed(self.player.in_previous_rounds())),
           # 'selected_payoff': player_in_all_rounds()[self.session.vars['paying_round']].payoff,
          'paying_round1': self.session.vars['paying_round1'],
            'paying_round2': self.session.vars['paying_round2'],
            'player_in_previous_rounds': self.player.in_previous_rounds(),
        # (above) Gives them a list of things they did in the past. How we construct a history table
            'opponent_in_previous_rounds': opponent.in_previous_rounds(),

        }

page_sequence = [

    Instructions,

    Instructions2,

    Instructions3,

    Diagram,

    Instructions4,

    RoleAssignment,

    Results,

    NewPartner,

    NewPartnerReceiver,

    Send,

    ReceiverWaitPage,

    Receiver,

    SenderWaitPage,

    RoundResults,

    ResultsWaitPage,

    Survey
]
